from flask import Flask, render_template, request, redirect, url_for, flash
import pickle
import pandas as pd
import numpy as np

app = Flask(__name__)
app.secret_key = "secret"

# Load model
model_svc = pickle.load(open("model_svr.pkl", "rb"))

# Human friendly dropdown maps
LABEL_MAP = {
    "Leather interior": {"Yes": 1, "No": 0},
    "Gear box type": {
        "Automatic": 0,
        "Tiptronic": 1,
        "CVT": 2,
        "Manual": 3
    },
    "Drive wheels": {
        "Front Wheel Drive": 0,
        "Rear Wheel Drive": 1,
        "All Wheel Drive": 2
    },
    "Wheel": {
        "Left wheel": 0,
        "Right wheel": 1
    },
    "Color": {
        "White": 12,
        "Black": 14,
        "Silver": 0,
        "Blue": 1,
        "Red": 2
    }
}

# Features in correct order
FEATURE_ORDER = [
    "ID","Levy","Manufacturer","Model","Prod. year","Category",
    "Leather interior","Engine volume","Mileage","Cylinders",
    "Gear box type","Drive wheels","Doors","Wheel","Color","Airbags"
]


@app.route("/")
def index():
    return render_template("index.html", label_map=LABEL_MAP)


@app.route("/predict", methods=["POST"])
def predict():

    try:
        data = []

        for feature in FEATURE_ORDER:

            value = request.form.get(feature)

            # Convert human labels → numbers
            if feature in LABEL_MAP:
                value = LABEL_MAP[feature][value]

            # Convert to numeric
            value = float(value)
            data.append(value)

        df = pd.DataFrame([data], columns=FEATURE_ORDER)
        pred = model_svc.predict(df)[0]

        return render_template("index.html", prediction=pred, label_map=LABEL_MAP)

    except Exception as e:
        flash(str(e), "danger")
        return redirect(url_for("index"))


if __name__ == "__main__":
    app.run(debug=True)
